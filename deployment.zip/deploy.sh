#!/bin/bash

# Exit on error
set -e

# Initialize variables
RESOURCE_GROUP=""
LOCATION="eastus"
BASE_NAME=""

# Parse command line arguments
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    -g|--resource-group)
      RESOURCE_GROUP="$2"
      shift
      shift
      ;;
    -l|--location)
      LOCATION="$2"
      shift
      shift
      ;;
    -n|--name)
      BASE_NAME="$2"
      shift
      shift
      ;;
    *)
      echo "Unknown option $1"
      exit 1
      ;;
  esac
done

# Check if resource group was provided
if [ -z "$RESOURCE_GROUP" ]; then
  echo "Resource group name is required. Use -g or --resource-group option."
  exit 1
fi

# Generate a base name if not provided
if [ -z "$BASE_NAME" ]; then
  BASE_NAME="animeapp$(date +%s)"
  echo "Using generated base name: $BASE_NAME"
fi

# Check if Azure CLI is installed
if ! command -v az &> /dev/null; then
  echo "Azure CLI is not installed. Please install it first."
  exit 1
fi

# Check if logged in to Azure
echo "Checking Azure login status..."
az account show &> /dev/null || {
  echo "Not logged in to Azure. Please run 'az login' first."
  exit 1
}

# Create resource group if it doesn't exist
echo "Creating resource group $RESOURCE_GROUP in $LOCATION if it doesn't exist..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" --output none

# Deploy Bicep template
echo "Deploying Azure resources using Bicep..."
DEPLOYMENT_OUTPUT=$(az deployment group create \
  --resource-group "$RESOURCE_GROUP" \
  --template-file "./infra/main.bicep" \
  --parameters baseName="$BASE_NAME" location="$LOCATION" \
  --output json)

# Extract values from deployment output
WEBAPP_URL=$(echo "$DEPLOYMENT_OUTPUT" | jq -r '.properties.outputs.webAppUrl.value')
STORAGE_ACCOUNT=$(echo "$DEPLOYMENT_OUTPUT" | jq -r '.properties.outputs.storageAccountName.value')
CONTAINER_NAME=$(echo "$DEPLOYMENT_OUTPUT" | jq -r '.properties.outputs.containerName.value')
OPENAI_ENDPOINT=$(echo "$DEPLOYMENT_OUTPUT" | jq -r '.properties.outputs.openAIEndpoint.value')

echo "Infrastructure deployment complete!"
echo "Web App URL: $WEBAPP_URL"
echo "Storage Account: $STORAGE_ACCOUNT"
echo "Container Name: $CONTAINER_NAME"
echo "OpenAI Endpoint: $OPENAI_ENDPOINT"

# Install dependencies
echo "Installing dependencies..."
npm install

# Deploy application to Web App
echo "Deploying application to Web App..."
zip -r deployment.zip . -x "node_modules/*" "deployment.zip"
az webapp deployment source config-zip --resource-group "$RESOURCE_GROUP" --name "${BASE_NAME}-webapp" --src "deployment.zip"

echo "Application deployment complete!"
echo "Your Anime Photo Generator is now available at: $WEBAPP_URL"